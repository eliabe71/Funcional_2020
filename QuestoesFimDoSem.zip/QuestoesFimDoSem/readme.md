#Considerações
Nas questões de Multiset recebi ajuda de um amigo que faz a cadeira com 
o professor wladmir