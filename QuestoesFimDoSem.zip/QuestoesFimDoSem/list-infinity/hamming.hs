{multipli:: Int->[Int]
multipli x = [x*y| y<-[2,3,5] ]
acheaPos xs xy = 
	if( head xs )  
hammingAux::[Int]->[Int]
hammingAux xs  = 
	if last xs  < head( multipli (head xs ))
		then xs ++ multipli (head [1])  
	else 

hamming:: Int->[Int]
hamming x = hammingAux }

