import Polinomio

makePol :: (Eq a, Num a) => [a] -> Polinomio a
makePol [] = polZero
makePol (x:xs) = if x /= 0 then (consPol x (length xs) (makePol xs)) else makePol xs

derivada pol
    | isPolZero pol = polZero
    | otherwise     = if g /= 0 then consPol (cl*g) (g-1) (derivada $ restoPol pol) else derivada $ restoPol pol
    where
    g  = grau pol
    cl = coefLider pol