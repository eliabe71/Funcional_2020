import Numeric

data Complex = Complex { real :: Float
                        ,img :: Float
                        } deriving (Eq)

instance Show Complex where
    show (Complex r i) = showFFloat (Just 3) r "" ++ " + " ++ showFFloat (Just 3) i "" ++ "i"

instance Num Complex where
    (+) (Complex r1 i1) (Complex r2 i2) = Complex (r1 + r2) (i1 + i2)
    (-) (Complex r1 i1) (Complex r2 i2) = Complex (r1 - r2) (i1 - i2)
    (*) (Complex r1 i1) (Complex r2 i2) = Complex (r1*r2 - i1*i2) (r1*i2 + i1*r2)
    negate (Complex r i)                = Complex (-r) (-i)
    abs    (Complex r i)                = Complex (sqrt(r*r + i*i)) 0
    signum (Complex r i)                = Complex ((r)/(sqrt(r*r + i*i))) ((i)/(sqrt(r*r + i*i)))
    fromInteger n                       = Complex (fromIntegral n) 0